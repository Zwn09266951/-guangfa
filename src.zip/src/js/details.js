//文章详情页
//
var windowhref = window.location.href;
var selectbyuserid = windowhref.indexOf('#');
var url = windowhref.substring(selectbyuserid+1);
_get(url)
.then(function (res) {
  console.log(res);
  var detailsTitle = $('#detailsTitle');
  var detailsShare = $('#detailsShare');
  var detailsInfo = $('#detailsInfo');
  var detailsContent = $('#detailsContent');
  var detailsBar = $('.details-mune--bar');
  var xsBarhtml = "<a href='/'>首页</a><span>&gt;</span><a href='center.html'>知识中心</a><span>&gt;</span><a href='center.html'>新手入门</a><span>&gt;</span>";
  var jjBarhtml = "<a href='/'>首页</a><span>&gt;</span><a href='center.html'>知识中心</a><span>&gt;</span><a href='center2.html'>进阶知识</a><span>&gt;</span>"
  var zzBarhtml = "<a href='/'>首页</a><span>&gt;</span><a href='center.html'>知识中心</a><span>&gt;</span><a href='center3.html'>政策法规</a><span>&gt;</span>"
  var article = res.d.article;
  var aa = $.parseHTML(article.content);
  detailsTitle.html(article.title);
  detailsShare.find('p').html(article.data);
  detailsInfo.find('b').html(article.excerpt);
  detailsContent.html(aa[0].data);
  detailsShare.find('span').eq(0).addClass('returnlist').html(article.tag);

  switch (article.tag) {
    case '新手入门':
      xsBarhtml += "<a class='returnlist'>国家法律</a>";
      detailsBar.html(xsBarhtml);
      break;
    case '进阶知识':
      jjBarhtml += "<a class='returnlist'>进阶知识</a>";
      detailsBar.html(jjBarhtml);
      break;
    case '国家法律':
      zzBarhtml += "<a class='returnlist'>国家法律</a>";
      detailsBar.html(zzBarhtml);
      break;
    case '行政法规':
      zzBarhtml += "<a class='returnlist'>行政法规</a>";
      detailsBar.html(zzBarhtml);
      break;
    case '部门规章':
      zzBarhtml += "<a class='returnlist'>部门规章</a>";
      detailsBar.html(zzBarhtml);
      break;
    case '交易所规则':
      zzBarhtml += "<a class='returnlist'>交易所规则</a>";
      detailsBar.html(zzBarhtml);
      break;
    case '自律规则':
      zzBarhtml += "<a class='returnlist'>自律规则</a>";
      detailsBar.html(zzBarhtml);
      break;
    case '反洗钱':
      zzBarhtml += "<a class='returnlist'>反洗钱</a>";
      detailsBar.html(zzBarhtml);
      break;
    case '普法规则':
      zzBarhtml += "<a class='returnlist'>普法规则</a>";
      detailsBar.html(zzBarhtml);
      break;
    }
  $('.returnlist').click(function(event) {
    switch (article.tag) {
      case '国家法律':
        window.location.href = 'center3.html#' + 'gjfl';
        getlist(GET_STATUTES);
        $('.mune-bottom--list').eq(0).addClass('active').siblings().removeClass('active');
        break;
      case '行政法规':
        window.location.href = 'center3.html#' + 'xzfg';
        getlist(GET_ALOW);
        $('.mune-bottom--list').eq(1).addClass('active').siblings().removeClass('active');
        break;
      case '部门规章':
        window.location.href = 'center3.html#' + 'bmgz';
        getlist(GET_DLOW);
        $('.mune-bottom--list').eq(2).addClass('active').siblings().removeClass('active');
        break;
      case '交易所规则':
        window.location.href = 'center3.html#' + 'jysgz';
        getlist(GET_ELOW);
        $('.mune-bottom--list').eq(3).addClass('active').siblings().removeClass('active');
        break;
      case '自律规则':
        window.location.href = 'center3.html#' + 'zlgz';
        getlist(GET_SRULE);
        $('.mune-bottom--list').eq(4).addClass('active').siblings().removeClass('active');
        break;
      case '反洗钱':
        window.location.href = 'center3.html#' + 'fxq';
        getlist(GET_MRULE);
        $('.mune-bottom--list').eq(5).addClass('active').siblings().removeClass('active');
        break;
      case '普法规则':
        window.location.href = 'center3.html#' + 'pfgz';
        getlist(GET_LRULE);
        $('.mune-bottom--list').eq(6).addClass('active').siblings().removeClass('active');
        break;
      case '普法规则':
        window.location.href = 'center3.html#' + 'pfgz';
        getlist(GET_LRULE);
        $('.mune-bottom--list').eq(6).addClass('active').siblings().removeClass('active');
        break;
      case '普法规则':
        window.location.href = 'center3.html#' + 'pfgz';
        getlist(GET_LRULE);
        $('.mune-bottom--list').eq(6).addClass('active').siblings().removeClass('active');
        break;

    }
  });

})
